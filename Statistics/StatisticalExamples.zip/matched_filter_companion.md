# Matched Filtering Under a Common Mask

## A concrete numerical companion to *Statistical Phantoms* §4.3 and *Common Mask Correlation* §6

*Working Document · April 2026*

*Companion to: Common Mask Correlation; Statistical Phantoms; PCA Under a Regional Spatial Mask; Regression with Omitted Variables*

---

## Preface

Matched filtering is the canonical detection algorithm in signal processing: given a template $t$ representing the signature of an event, search for the event in noisy data $d$ by computing $\langle t, d\rangle$ and thresholding. The detection statistic's null distribution sets the false-alarm rate; the signal-to-noise ratio under hypothesized presence sets the detection rate.

The framework's claim from `common_mask_correlation.md` §6 and `statistical_phantoms.md` §4.3: *under a common mask shared between data and template, the detection statistic's null variance is non-uniform across template parameter space.* Some templates have suppressed sensitivity (those whose support overlaps the gap); some have inflated variance and produce more frequent false alarms. The non-uniformity is computable in advance from the mask geometry alone — not from the data.

This document demonstrates the prediction. Setup: 1D periodic domain with a measurement gap, Gaussian templates parameterized by location, sweep through template parameter space, compute the false-alarm map both empirically (Monte Carlo over null realizations) and from the framework's prediction. Verify: empirical and predicted match within finite-sample noise; the four-object identity holds to machine precision per template location.

The companion script `matched_filter_demonstration.py` produces all figures and the verification record.

---

## Part I — Setup

### 1.1 Domain, gap, templates

Take a 1D periodic domain $\Omega = [0, 2\pi]$ discretized as $N = 256$ points. The measurement gap is $G = [\pi/2, 3\pi/4]$, occupying $\pi/4 \approx 12.5\%$ of the domain. The mask operator is multiplication by $M_G(x) = \mathbb{1}\{x \notin G\}$.

Templates are unit-norm Gaussians of width $\sigma = 0.15$ centered at varying locations $\xi$:

$$t_\xi(x) = c_\sigma \exp\left(-\frac{d_{\text{periodic}}(x, \xi)^2}{2\sigma^2}\right), \qquad \|t_\xi\|_{L^2} = 1.$$

The template's location $\xi$ is the parameter being searched over — the matched-filter detection problem at each $\xi$ is: "is there an event of shape $t_\xi$ in the data?"

![Setup: domain, gap, templates at three locations](matched_filter_setup.png)

A template far from the gap has nearly all its mass outside $G$ (the surviving fraction $\beta_\xi = \int_{\Omega \setminus G} t_\xi^2 \approx 1$). A template centered inside the gap has nearly all its mass inside $G$ ($\beta_\xi \approx 0$). Templates straddling the gap edge have intermediate $\beta_\xi$.

### 1.2 Forward operator and detection statistic

The forward operator $A: H \to H$ models the masking process: $(Af)(x) = M_G(x) f(x)$. Both signal and noise pass through $A$, so the observed data is $d = A(s + n)$ where $s = c \cdot t_{\xi_*}$ is a candidate signal at unknown amplitude and location and $n$ is noise.

Detection statistic at template location $\xi$:

$$T(\xi) = \langle t_\xi, d\rangle = \langle t_\xi, M_G \cdot (s + n)\rangle = \langle M_G t_\xi, s + n\rangle.$$

Under the null hypothesis $s = 0$ with white noise $n$ of variance $\sigma_n^2$, the detection statistic is Gaussian with mean zero and variance

$$\mathrm{Var}[T(\xi) \mid \text{null}] = \sigma_n^2 \|M_G t_\xi\|^2 = \sigma_n^2 \beta_\xi.$$

This is the framework's central claim: the null variance is $\beta_\xi$, the squared mass of the template outside the gap. *It varies with $\xi$.*

A standard matched-filtering analysis assumes the null variance is $\sigma_n^2$ (the white-noise variance, uniform across templates). At a fixed detection threshold $\tau$, the assumed false-alarm rate is $2(1 - \Phi(\tau / \sigma_n))$, the same for all $\xi$. Under the common mask, the actual false-alarm rate is $2(1 - \Phi(\tau / (\sigma_n \sqrt{\beta_\xi})))$, varying with $\xi$. Templates near or in the gap have $\beta_\xi \to 0$, so the actual false-alarm rate at fixed threshold drops to zero (no false alarms because no signal can reach the detector). Templates far from the gap have $\beta_\xi \approx 1$, so the false-alarm rate matches the assumed value.

---

## Part II — Template Distortion

The framework reads the matched-filtering setup through the lens of the Halmos two-projection geometry with $P_1 = \mathrm{span}(t_\xi)$ (the 1D subspace spanned by the template) and $P_2 = M_G$ (the unmasked region). The principal angle $\theta_\xi$ between these subspaces satisfies $\cos^2\theta_\xi = \beta_\xi$, the mass of the template outside the gap.

The **effective template** under masking is $A^* A t_\xi = M_G t_\xi$ — the template with its mass inside $G$ zeroed. This is what the data actually responds to; what the matched filter actually integrates against. The original template $t_\xi$ is a fiction in the masked-data setting.

![Template distortion at five locations](matched_filter_template_distortion.png)

Five representative locations:
- $\xi = \pi/4$ (far-left): $\beta_\xi \approx 1$. Effective template is essentially the original.
- $\xi$ at left gap edge: $\beta_\xi \approx 0.5$. Effective template is the original with the right-half cut off.
- $\xi$ at gap center: $\beta_\xi \approx 0$. Effective template is essentially zero — the matched filter has no signal sensitivity at this location regardless of how strong the actual source.
- $\xi$ at right gap edge: $\beta_\xi \approx 0.5$. Symmetric to the left edge.
- $\xi = 3\pi/2$ (far-right): $\beta_\xi \approx 1$. Effective template is essentially the original.

The detection-statistic null variance scales as $\beta_\xi$. Sources detected with $\xi$ far from the gap behave normally. Sources hypothesized to be inside the gap are simply undetectable. Sources straddling the gap edge have suppressed sensitivity but are still detectable, with reduced SNR proportional to $\sqrt{\beta_\xi}$.

---

## Part III — The False-Alarm Map

The most operationally important phenomenon: at fixed detection threshold $\tau$, the false-alarm rate as a function of template location $\xi$ is non-uniform. The framework predicts the shape; Monte Carlo over null realizations confirms it.

![False-alarm map across template parameter space](matched_filter_falsealarm_map.png)

Top panel: detection-statistic null variance as a function of $\xi$. Predicted (steel blue): $\beta_\xi = \|M_G t_\xi\|^2$, computed in advance from the mask geometry alone. Empirical (firebrick): variance of the matched-filter response over $T = 200$ null realizations. The two curves match: the variance dips to zero in the gap region, recovering to ~1 outside. The empirical curve has $\sim 10\%$ noise from finite-sample variance estimation.

Bottom panel: false-alarm rate at fixed threshold $\tau \approx 1.4$. Predicted: $2(1 - \Phi(\tau / \sqrt{\beta_\xi}))$. Empirical: fraction of $T = 5000$ null realizations exceeding the threshold. The two curves match closely (mean relative error 2.1%). The false-alarm rate drops from $\sim 0.16$ outside the gap to essentially zero inside the gap.

The pattern is what an unaware analyst would interpret as: "the data inside the gap is exceptionally clean — no spurious detections at all in that region." The framework's reading: the detection algorithm is structurally insensitive in that region; the lack of detections is not low contamination but no probe sensitivity. *Templates inside the gap could not detect a real signal even if one were present at full amplitude.*

This is the false-alarm-map analog of what `common_mask_correlation.md` §6 derives algebraically. The phenomenon is computable in advance from $\beta_\xi$ alone, without any data; the empirical confirmation establishes that the prediction matches reality.

---

## Part IV — The Four-Object Decomposition

The four-object decomposition (`statistical_phantoms.md` §1.3) specializes per template location. With $P_1 = \mathrm{span}(t_\xi)$ (1D) and $P_2 = M_G$:

| Object | Per-location value | Interpretation in matched-filter setting |
|---|---|---|
| Retention | $\beta_\xi^2$ | Squared SNR retention for true source at location $\xi$ |
| Suppression | $(1 - \beta_\xi)^2$ | Squared SNR loss from masking |
| Leakage | $\beta_\xi(1 - \beta_\xi)$ | Coupling between templates: nearby templates' false alarms correlate |
| Total | $1 - \beta_\xi$ | Full $L^2$ distance from $t_\xi$ to its effective version |

with the per-location identity $1 - \beta_\xi = (1-\beta_\xi)^2 + \beta_\xi(1-\beta_\xi)$ verified to machine precision.

![Four-object decomposition vs template location](matched_filter_decomposition.png)

Left panel: four scalar laws as functions of $\xi$. The structure is symmetric around the gap center. Outside the gap: retention dominates ($\beta_\xi^2 \approx 1$), suppression is near zero, leakage is near zero, total error is near zero — the masking is effectively invisible to templates far from $G$. At the gap edges: leakage peaks at $\beta_\xi(1-\beta_\xi) = 1/4$ when $\beta_\xi = 1/2$ — templates straddling the gap edge have maximum coupling to other templates' detection-statistic structure. Inside the gap center: suppression dominates ($(1-\beta_\xi)^2 \approx 1$), retention is near zero, total error is near 1 — templates inside the gap have full SNR loss.

Right panel: the four scalar laws as functions of $\beta$, with vertical guides at the five representative $\xi$ values (far-left, at-left-edge, in-gap, at-right-edge, far-right). The Bernoulli-like leakage law $\beta(1-\beta)$ peaks at $\beta = 1/2$ — exactly at the gap edges, where the template's mass is half-in / half-out.

The leakage column has operational consequences for survey-style searches. When matched-filter searches are run over many template locations and the detection statistic is corrected for non-uniform null variance (whitened), the template-to-template correlations are governed by leakage. Adjacent templates in $\xi$ that both have $\beta_\xi \approx 1/2$ have correlated false-alarm responses. The framework's leakage column quantifies this coupling exactly.

---

## Part V — Verification

### 5.1 Four-object identity

Across all template locations $\xi$ tested:

```
max |total - suppression - leakage| = 6.94e-17 (machine precision)
```

The per-location identity is exact.

### 5.2 Null variance prediction

```
Predicted: variance = β_ξ = ||M_G t_ξ||² (no data needed)
Empirical: variance from T=200 Monte Carlo null realizations
Mean relative error: 10.1%
Max relative error:  27.2%
```

The 10% mean error reflects the finite-sample noise of variance estimation with $T = 200$ — variance estimates have $\sqrt{2/(T-1)} \approx 10\%$ standard error in this regime, consistent with the observed deviation. Not a framework error; sampling error.

### 5.3 False-alarm rate prediction

```
Predicted: P(|N(0, β_ξ)| > τ) at fixed threshold τ=1.403
Empirical: fraction of T=5000 null realizations exceeding τ
Mean relative error: 2.1%
```

With 5000 MC realizations, the false-alarm rate empirical and predicted curves match closely (Figure 3 bottom panel).

### 5.4 Template distortion verification

For each of the five representative locations:

| Location | Predicted $\beta_\xi$ | Empirical $\|M_G t_\xi\|^2$ |
|---|---|---|
| Far-left ($\xi = \pi/4$) | 1.000 | 1.000 |
| Left edge ($\xi = \pi/2 - 0.1$) | 0.752 | 0.752 |
| Gap center | 0.000 | 0.000 |
| Right edge ($\xi = 3\pi/4 + 0.1$) | 0.752 | 0.752 |
| Far-right ($\xi = 3\pi/2$) | 1.000 | 1.000 |

These are computed identically (the prediction is just the formula evaluated). The verification is that this computed quantity matches the detection-statistic null variance (verified in §5.2).

---

## Part VI — What This Demonstrates

1. **The detection-statistic null variance is non-uniform across template parameter space.** The variance at each template location $\xi$ is $\beta_\xi$, computable from the mask geometry alone. The framework predicts the entire variance map without any data.

2. **The false-alarm rate is non-uniform.** At fixed detection threshold, the rate of spurious detections varies across $\xi$. Templates inside the gap have false-alarm rate near zero — not because the data is clean there but because the matched filter has no probe sensitivity. Templates far from the gap have the assumed nominal rate. Templates near the edge have intermediate rates.

3. **The non-uniformity has structure.** It's not random; it's the function $\beta_\xi$, and that function is computable. Unaware matched-filter analyses that assume uniform null variance will misread the false-alarm structure.

4. **The four-object decomposition gives the per-direction accounting.** Retention, suppression, leakage, total: each has an interpretation specific to matched filtering (SNR retention, SNR loss, template-to-template coupling, full L² distance). The structural identity holds to machine precision.

5. **The framework's prediction is exact, modulo finite-sample noise.** Both the variance prediction and the false-alarm-rate prediction match Monte Carlo to within sampling error. With more null realizations, the empirical curves converge to the predicted curves at the rate $1/\sqrt{T}$.

The framework's contribution to matched-filtering analysis is naming what's happening when data has been masked: the detection-statistic structure is no longer the textbook structure. Variance is non-uniform; false-alarm rates vary by template location; sensitivity is suppressed in some regions of parameter space and inflated in others. None of this is detectable from the data alone (the data shows what it shows); it must be read from the mask geometry, which is the framework's input.

The connection to `common_mask_correlation.md` §6 is direct: this document is the numerical demonstration of the algebraic claims in §6 ("the matched-filter null variance is $A^* A t_\xi$ with $A = $ the masking operator") on a specific concrete setup.

---

## Development Record

This document is the third concrete numerical companion to `statistical_phantoms.md` Part IV (after `pca_masked_companion.md` for §4.2 and `regression_omitted_companion.md` for §4.1). It establishes the matched-filtering-under-common-mask case at the same level of empirical verification: predictions match Monte Carlo to within finite-sample noise, four-object identities hold to machine precision per template location.

What this document does:

- Sets up matched filtering on a 1D periodic domain with a regional gap and Gaussian templates parameterized by location.
- Computes the detection-statistic null variance both empirically (Monte Carlo over null realizations) and from the framework's prediction $\beta_\xi$.
- Demonstrates the false-alarm map: at fixed detection threshold, the rate of spurious detections varies non-uniformly across template parameter space, computed in advance from the mask geometry.
- Verifies the four-object decomposition's structural identities to machine precision per template location.

What this document does not do:

- Address colored noise (general $\Sigma_n \neq \sigma^2 I$). The framework's general formula is $\sigma^2 t^T A^* \Sigma_n^{-1} A t$, of which our white-noise case is the simplest. Colored-noise extension would replace $M_G$ with a more elaborate operator but the structural claims (non-uniform variance, four-object identity) carry through.
- Develop the multi-detector case (gravitational-wave-style coincident detection across multiple instruments with shared mask). `common_mask_correlation.md` §7 sketches the multi-detector formalism.
- Compare with whitening procedures used in real survey-style matched-filter pipelines (LIGO/Virgo, CMB power-spectrum estimation, fast-radio-burst searches). Standard practice partially compensates for the variance non-uniformity through pre-processing whitening; the framework's reading is whether that whitening is consistent with the underlying $\beta_\xi$ structure.
- Address the parameter-estimation side of matched filtering (not just detection but locating the source). The framework predicts a corresponding non-uniform Cramér-Rao bound; not numerically demonstrated here.

Likely revisions:

- The 1D Gaussian-template setup is simple by design. Real applications (gravitational waves, radar) use templates with more elaborate structure (chirping, polarization). The structural prediction $\beta_\xi = \|M_G t_\xi\|^2$ holds, but the per-template computation becomes more involved.
- The connection to apodization and spectral-leakage corrections in time-series analysis is implicit. Drawing the explicit map (apodization is a soft mask; spectral leakage is the leakage column of the four-object decomposition for Fourier templates) would broaden the document's audience.

The role of this companion. Together with `pca_masked_companion.md` and `regression_omitted_companion.md`, this document establishes the third realization of the statistical phantom framework with concrete numerical verification. The framework predicts pointwise structure of the detection-statistic null behavior under masking; the prediction matches Monte Carlo to within sampling error. The false-alarm-map prediction is the operationally important piece — survey-style matched-filter analyses can read the predicted map directly from the mask geometry and adjust thresholds or whitening accordingly.
