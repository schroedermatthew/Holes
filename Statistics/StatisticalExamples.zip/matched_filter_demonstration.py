"""
Matched filtering under common mask: numerical companion to common_mask_correlation.md §6
and statistical_phantoms.md §4.3

Setup:
- 1D periodic domain [0, 2pi], discretized as N=256 points, Fourier basis
- Measurement gap G = [pi/2, 3pi/4] (pi/4 wide, ~12.5% of domain)
- Forward operator A = I - K on Fourier coefficients, K_mn = integral over G
- Templates parameterized by location: t_xi(x) = Gaussian peak at xi
- Detection statistic for template at xi under null:
    T(xi) = (template_xi)^T (mask data) — a real number
  Variance of T(xi) under null is non-uniform in xi due to the mask

Framework's predictions (from common_mask_correlation §6 and statistical_phantoms §4.3):
- Effective masked template: A^T A t_xi (quadratic in mask)
- Detection statistic null variance: t_xi^T A^T A t_xi (assuming white noise)
- Non-uniform false-alarm rate: t_xi^T A^T A t_xi varies with xi
- Templates whose support overlaps with the gap have suppressed sensitivity;
  templates whose support straddles the gap edge have inflated/distorted statistics
- Four-object decomposition with P_1 = span(t_xi), P_2 = M_G:
  - Retention beta^2: SNR retention for true source at xi
  - Suppression (1-beta)^2: SNR loss
  - Leakage beta(1-beta): false-alarm coupling between adjacent templates

Output:
- matched_filter_setup.png: domain, gap, sample template, masked sample data
- matched_filter_template_distortion.png: true vs effective masked template
- matched_filter_falsealarm_map.png: detection-statistic null variance vs xi
- matched_filter_decomposition.png: four-object decomposition
- matched_filter_verification.txt: numerical verification
"""

import os
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle

OUTPUT_DIR = '/mnt/user-data/outputs'
os.makedirs(OUTPUT_DIR, exist_ok=True)

np.random.seed(42)

# ============================================================
# SETUP
# ============================================================

# 1D periodic domain
N = 256
L = 2 * np.pi
x = np.linspace(0, L, N, endpoint=False)
dx = L / N

# Gap region G
gap_start = np.pi / 2
gap_end = 3 * np.pi / 4
in_gap = (x >= gap_start) & (x < gap_end)
M_G = (~in_gap).astype(float)  # 1 outside gap, 0 inside
gap_fraction = in_gap.sum() / N

print(f"Gap: [{gap_start:.4f}, {gap_end:.4f}]")
print(f"Gap fraction: {gap_fraction:.3f}")

# ============================================================
# TEMPLATE DEFINITION
# ============================================================

# Templates: Gaussian peaks of width sigma at location xi
def gaussian_template(xi, x, sigma=0.15):
    """Periodic Gaussian template centered at xi."""
    # Use minimum periodic distance
    d = np.minimum(np.abs(x - xi), L - np.abs(x - xi))
    t = np.exp(-d**2 / (2 * sigma**2))
    # Normalize to unit L^2 norm (using grid integration)
    norm = np.sqrt(np.sum(t**2) * dx)
    return t / norm

# A specific template at xi = pi/3 for visualization
xi_demo = np.pi / 3
t_demo = gaussian_template(xi_demo, x)

# ============================================================
# THE FORWARD OPERATOR A = I - K
# ============================================================

# In position-space representation: applying A to a function is just multiplication by M_G
# Because: (Af)(x) = f(x) for x not in G, 0 for x in G
# So in position space, A f = M_G * f
# (We can also represent A in Fourier basis, but for the visualization
# the position-space view is cleaner)

# Effective masked template: A^T A t (when noise covariance is identity)
# (A^T A)f = M_G * (M_G * f) = M_G * f (since M_G is idempotent)
# So in this simple case A^T A = M_G

# But for the variance of the detection statistic under colored noise that
# has been processed through A, we have:
# Var[T(xi) | null] = t_xi^T A^T Sigma_n A t_xi
# If Sigma_n = sigma^2 I, then this is sigma^2 * ||A t_xi||^2 = sigma^2 * ||M_G t_xi||^2
# = sigma^2 * integral over (Omega \ G) of t_xi^2

def detection_variance(t_xi, M_G, dx, noise_var=1.0):
    """Null variance of detection statistic for template t at xi."""
    return noise_var * np.sum((M_G * t_xi)**2) * dx

# ============================================================
# FIGURE 1: SETUP
# ============================================================

fig, axes = plt.subplots(1, 3, figsize=(13, 4))

# Domain with gap
ax = axes[0]
ax.fill_between(x, -1, 1, where=in_gap, color='gray', alpha=0.4, label='Gap $G$')
ax.axhline(0, color='black', linewidth=0.5)
ax.set_xlim(0, L)
ax.set_ylim(-1, 1)
ax.set_xlabel('x')
ax.set_title(f"Domain: $[0, 2\\pi]$ with gap $G = [\\pi/2, 3\\pi/4]$\n(gap fraction = {gap_fraction:.3f})")
ax.set_xticks([0, np.pi/2, np.pi, 3*np.pi/2, 2*np.pi])
ax.set_xticklabels(['0', '$\\pi/2$', '$\\pi$', '$3\\pi/2$', '$2\\pi$'])
ax.legend(loc='upper right')

# Sample template
ax = axes[1]
ax.plot(x, t_demo, color='steelblue', linewidth=2, label=f'Template at $\\xi = \\pi/3$')
ax.fill_between(x, 0, t_demo, where=in_gap, color='red', alpha=0.3)
ax.fill_between(x, 0, t_demo, where=~in_gap, color='steelblue', alpha=0.2)
ax.fill_between(x, t_demo.min()*1.1, t_demo.max()*1.1, where=in_gap, color='gray', alpha=0.3)
ax.set_xlim(0, L)
ax.set_xlabel('x')
ax.set_ylabel('$t_\\xi(x)$')
ax.set_title("A template far from the gap\n(most of its mass is outside G)")
ax.set_xticks([0, np.pi/2, np.pi, 3*np.pi/2, 2*np.pi])
ax.set_xticklabels(['0', '$\\pi/2$', '$\\pi$', '$3\\pi/2$', '$2\\pi$'])
ax.legend(loc='upper right')

# Sample template inside gap
ax = axes[2]
xi_in_gap = (gap_start + gap_end) / 2
t_in_gap = gaussian_template(xi_in_gap, x, sigma=0.05)
ax.plot(x, t_in_gap, color='steelblue', linewidth=2, label=f'Template at center of gap')
ax.fill_between(x, 0, t_in_gap, where=in_gap, color='red', alpha=0.5, label='Mass inside gap')
ax.fill_between(x, 0, t_in_gap, where=~in_gap, color='steelblue', alpha=0.2)
ax.fill_between(x, 0, t_in_gap.max()*1.1, where=in_gap, color='gray', alpha=0.3)
ax.set_xlim(0, L)
ax.set_xlabel('x')
ax.set_ylabel('$t_\\xi(x)$')
ax.set_title("A narrow template centered inside the gap\n(most of its mass is inside G)")
ax.set_xticks([0, np.pi/2, np.pi, 3*np.pi/2, 2*np.pi])
ax.set_xticklabels(['0', '$\\pi/2$', '$\\pi$', '$3\\pi/2$', '$2\\pi$'])
ax.legend(loc='upper right')

plt.suptitle("Setup: matched-filtering on a 1D periodic domain with a measurement gap", fontsize=13)
plt.tight_layout()
plt.savefig(f'{OUTPUT_DIR}/matched_filter_setup.png', dpi=100, bbox_inches='tight')
plt.close()
print(f"Saved {OUTPUT_DIR}/matched_filter_setup.png")

# ============================================================
# FIGURE 2: TEMPLATE DISTORTION
# ============================================================

# For each xi, the effective template becomes M_G * t_xi
# Show this for a few representative xi values

xi_examples = [
    np.pi/4,                           # well outside gap
    gap_start - 0.1,                   # at left edge of gap
    (gap_start + gap_end)/2,           # at center of gap
    gap_end + 0.1,                     # at right edge of gap
    3*np.pi/2,                         # far on the other side
]
labels = [
    "Far from gap (left)",
    "At left edge of gap",
    "Center of gap (worst case)",
    "At right edge of gap",
    "Far from gap (right)",
]

fig, axes = plt.subplots(len(xi_examples), 2, figsize=(13, 12))

beta_vals = []
for k, (xi, label) in enumerate(zip(xi_examples, labels)):
    sigma_template = 0.15  # consistent template width
    t_xi = gaussian_template(xi, x, sigma=sigma_template)
    eff_template = M_G * t_xi  # the effective template
    
    # Compute beta_xi: fraction of template mass outside gap
    beta_xi = np.sum(eff_template**2) * dx / (np.sum(t_xi**2) * dx)
    beta_vals.append(beta_xi)
    a_xi = 1 - beta_xi  # mass-in-gap fraction
    
    # Left: original template
    ax = axes[k, 0]
    ax.plot(x, t_xi, color='steelblue', linewidth=2, label='True template $t_\\xi$')
    ax.fill_between(x, 0, t_xi.max()*1.1, where=in_gap, color='gray', alpha=0.3)
    ax.set_xlim(0, L)
    ax.set_ylim(-0.05, t_xi.max()*1.1)
    ax.set_title(f"$\\xi = {xi:.3f}$ — {label}\n$\\beta_\\xi = $ fraction outside gap = {beta_xi:.3f}, $a_\\xi$ = mass in gap = {a_xi:.3f}")
    ax.set_xticks([0, np.pi/2, np.pi, 3*np.pi/2, 2*np.pi])
    ax.set_xticklabels(['0', '$\\pi/2$', '$\\pi$', '$3\\pi/2$', '$2\\pi$'])
    ax.axvline(xi, color='red', linestyle='--', alpha=0.5, label=f'$\\xi$={xi:.2f}')
    ax.legend(loc='upper right', fontsize=9)
    ax.grid(alpha=0.3)
    
    # Right: effective masked template = M_G t_xi
    ax = axes[k, 1]
    ax.plot(x, t_xi, color='steelblue', linewidth=1, alpha=0.4, label='Original $t_\\xi$')
    ax.plot(x, eff_template, color='firebrick', linewidth=2, label='Effective $A^T A t_\\xi$')
    ax.fill_between(x, 0, t_xi.max()*1.1, where=in_gap, color='gray', alpha=0.3)
    ax.set_xlim(0, L)
    ax.set_ylim(-0.05, t_xi.max()*1.1)
    ax.set_title(f"Effective template (post-mask)\nDetection variance $\\propto \\beta_\\xi = {beta_xi:.3f}$")
    ax.set_xticks([0, np.pi/2, np.pi, 3*np.pi/2, 2*np.pi])
    ax.set_xticklabels(['0', '$\\pi/2$', '$\\pi$', '$3\\pi/2$', '$2\\pi$'])
    ax.axvline(xi, color='red', linestyle='--', alpha=0.5)
    ax.legend(loc='upper right', fontsize=9)
    ax.grid(alpha=0.3)

plt.suptitle("Template distortion under common mask: $t_\\xi$ vs effective $A^TA t_\\xi$ at five locations", fontsize=13)
plt.tight_layout()
plt.savefig(f'{OUTPUT_DIR}/matched_filter_template_distortion.png', dpi=100, bbox_inches='tight')
plt.close()
print(f"Saved {OUTPUT_DIR}/matched_filter_template_distortion.png")

# ============================================================
# FIGURE 3: FALSE-ALARM MAP
# ============================================================

# Sweep template location xi across the domain
n_xi = 200
xi_values = np.linspace(0, L, n_xi, endpoint=False)

# For each xi, compute:
#   beta_xi = fraction of template mass outside gap
#   detection variance = ||M_G t_xi||^2
#   (under null, detection statistic ~ N(0, var))
#   false-alarm rate at threshold tau scales with var

sigma_template = 0.15
betas = np.zeros(n_xi)
variances = np.zeros(n_xi)
for k, xi in enumerate(xi_values):
    t_xi = gaussian_template(xi, x, sigma=sigma_template)
    eff = M_G * t_xi
    betas[k] = np.sum(eff**2) * dx
    variances[k] = np.sum(eff**2) * dx  # = beta_k for unit-norm templates

# Empirical: Monte Carlo with N_mc null realizations
n_mc = 200
np.random.seed(123)
mc_responses = np.zeros((n_mc, n_xi))
for m in range(n_mc):
    null_data = np.random.randn(N) * np.sqrt(1/dx)  # normalized white noise
    null_data_masked = M_G * null_data
    for k, xi in enumerate(xi_values):
        t_xi = gaussian_template(xi, x, sigma=sigma_template)
        mc_responses[m, k] = np.sum(t_xi * null_data_masked) * dx

empirical_var = mc_responses.var(axis=0)

# Run more realizations to compute false-alarm rate at fixed threshold
n_mc_far = 5000
np.random.seed(456)
mc_responses_far = np.zeros((n_mc_far, n_xi))
for m in range(n_mc_far):
    null_data = np.random.randn(N) * np.sqrt(1/dx)
    null_data_masked = M_G * null_data
    for k, xi in enumerate(xi_values[::5]):  # subsample for speed
        t_xi = gaussian_template(xi, x, sigma=sigma_template)
        idx_full = list(xi_values).index(xi)
        mc_responses_far[m, idx_full] = np.sum(t_xi * null_data_masked) * dx

# Use a threshold based on the average variance
threshold = 1.5 * np.sqrt(np.mean(variances))

# False-alarm rate at the subsampled xi values
xi_subsampled = xi_values[::5]
n_subsampled = len(xi_subsampled)
fa_rate = np.zeros(n_subsampled)
predicted_fa_rate = np.zeros(n_subsampled)
for ki, xi in enumerate(xi_subsampled):
    k = ki * 5
    fa_rate[ki] = (np.abs(mc_responses_far[:, k]) > threshold).mean()
    # Predicted: P(|N(0, var)| > threshold)
    from scipy.stats import norm
    sigma_xi = np.sqrt(variances[k])
    predicted_fa_rate[ki] = 2 * (1 - norm.cdf(threshold / sigma_xi))

# ============================================================

fig, axes = plt.subplots(2, 1, figsize=(13, 8))

# Top: detection-statistic null variance as a function of xi
ax = axes[0]
ax.fill_between(xi_values, 0, betas.max()*1.1, where=(xi_values >= gap_start) & (xi_values < gap_end),
                color='gray', alpha=0.3, label='Gap region')
ax.plot(xi_values, variances, color='steelblue', linewidth=2, label=r'Predicted variance $\beta_\xi$')
ax.plot(xi_values, empirical_var, color='firebrick', linewidth=1, alpha=0.7, 
        marker='.', markersize=2, label='Empirical (MC, T=200 nulls)')

# Mark the worst (most-suppressed) and the boundary points
ax.axvline(gap_start, color='black', linestyle='--', alpha=0.5)
ax.axvline(gap_end, color='black', linestyle='--', alpha=0.5)

ax.set_xlim(0, L)
ax.set_xlabel('Template location $\\xi$')
ax.set_ylabel('Detection-statistic null variance')
ax.set_title("Null variance of detection statistic across template parameter space")
ax.legend(loc='lower right')
ax.set_xticks([0, np.pi/2, np.pi, 3*np.pi/2, 2*np.pi])
ax.set_xticklabels(['0', '$\\pi/2$', '$\\pi$', '$3\\pi/2$', '$2\\pi$'])
ax.grid(alpha=0.3)

# Annotate
mid_var = np.mean(variances[~((xi_values >= gap_start - 0.5) & (xi_values < gap_end + 0.5))])
ax.text(0.05, 0.95, f"Far from gap: $\\beta \\approx 1$, normal variance\nNear/in gap: $\\beta \\to (1-a_\\xi)$, suppressed\nat center of gap: maximum suppression", 
        transform=ax.transAxes, va='top',
        bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))

# Bottom: false-alarm rate
ax = axes[1]
ax.fill_between(xi_subsampled, 0, max(fa_rate.max(), predicted_fa_rate.max())*1.1, 
                where=(xi_subsampled >= gap_start) & (xi_subsampled < gap_end),
                color='gray', alpha=0.3, label='Gap region')
ax.plot(xi_subsampled, predicted_fa_rate, color='steelblue', linewidth=2, label='Predicted FA rate')
ax.plot(xi_subsampled, fa_rate, color='firebrick', linewidth=1, alpha=0.8, 
        marker='o', markersize=3, label=f'Empirical (MC, T={n_mc_far} nulls)')
ax.axvline(gap_start, color='black', linestyle='--', alpha=0.5)
ax.axvline(gap_end, color='black', linestyle='--', alpha=0.5)
ax.set_xlim(0, L)
ax.set_xlabel('Template location $\\xi$')
ax.set_ylabel('False-alarm rate')
ax.set_title(f"False-alarm rate at threshold $\\tau = {threshold:.3f}$ across template parameter space")
ax.legend(loc='upper right')
ax.set_xticks([0, np.pi/2, np.pi, 3*np.pi/2, 2*np.pi])
ax.set_xticklabels(['0', '$\\pi/2$', '$\\pi$', '$3\\pi/2$', '$2\\pi$'])
ax.grid(alpha=0.3)

plt.suptitle("Non-uniform false-alarm rate across template parameter space\n(predicted from $\\beta_\\xi = \\|M_G t_\\xi\\|^2$ matches Monte Carlo)", fontsize=12)
plt.tight_layout()
plt.savefig(f'{OUTPUT_DIR}/matched_filter_falsealarm_map.png', dpi=100, bbox_inches='tight')
plt.close()
print(f"Saved {OUTPUT_DIR}/matched_filter_falsealarm_map.png")

# ============================================================
# FIGURE 4: FOUR-OBJECT DECOMPOSITION
# ============================================================

# For each template location xi, compute beta_xi (mass of template outside gap)
# and the four objects of the decomposition

# Per-template-location decomposition (template subspace is 1D, so single beta per xi)
retention_xi = betas**2          # peaks at beta=1 (template far from gap)
suppression_xi = (1 - betas)**2  # peaks at beta=0 (template in gap)
leakage_xi = betas * (1 - betas) # peaks at beta=1/2 (template straddles gap edge)
total_xi = 1 - betas             # peaks at beta=0 (template in gap)

fig, axes = plt.subplots(1, 2, figsize=(13, 5))

# Left: four objects as functions of xi
ax = axes[0]
ax.fill_between(xi_values, 0, 1.05, where=(xi_values >= gap_start) & (xi_values < gap_end),
                color='gray', alpha=0.3, label='Gap region')
ax.plot(xi_values, retention_xi, color='steelblue', linewidth=2, label=r'Retention $\beta^2$')
ax.plot(xi_values, suppression_xi, color='firebrick', linewidth=2, label=r'Suppression $(1-\beta)^2$')
ax.plot(xi_values, leakage_xi, color='goldenrod', linewidth=2, label=r'Leakage $\beta(1-\beta)$')
ax.plot(xi_values, total_xi, color='black', linewidth=2, alpha=0.5, linestyle='--', label=r'Total $1-\beta$')
ax.axvline(gap_start, color='black', linestyle=':', alpha=0.5)
ax.axvline(gap_end, color='black', linestyle=':', alpha=0.5)
ax.set_xlim(0, L)
ax.set_ylim(-0.05, 1.05)
ax.set_xlabel('Template location $\\xi$')
ax.set_ylabel('Scalar value')
ax.set_title("Four-object decomposition vs template location $\\xi$\n(per-direction laws of $\\beta_\\xi$)")
ax.legend(loc='center right')
ax.set_xticks([0, np.pi/2, np.pi, 3*np.pi/2, 2*np.pi])
ax.set_xticklabels(['0', '$\\pi/2$', '$\\pi$', '$3\\pi/2$', '$2\\pi$'])
ax.grid(alpha=0.3)

# Right: scalar laws as functions of beta
ax = axes[1]
beta_curve = np.linspace(0, 1, 100)
ax.plot(beta_curve, beta_curve**2, label=r'Retention $\beta^2$', color='steelblue', linewidth=2)
ax.plot(beta_curve, (1-beta_curve)**2, label=r'Suppression $(1-\beta)^2$', color='firebrick', linewidth=2)
ax.plot(beta_curve, beta_curve*(1-beta_curve), label=r'Leakage $\beta(1-\beta)$', color='goldenrod', linewidth=2)
ax.plot(beta_curve, 1-beta_curve, label=r'Total $1-\beta$', color='black', alpha=0.5, linewidth=2, linestyle='--')

# Mark a few specific xi values
for xi, lab in zip(xi_examples[:5], ['far-L', 'at-L-edge', 'in-gap', 'at-R-edge', 'far-R']):
    t_xi = gaussian_template(xi, x, sigma=0.15)
    eff = M_G * t_xi
    beta_x = np.sum(eff**2) * dx
    ax.axvline(beta_x, color='gray', alpha=0.3, linewidth=0.8)
    ax.annotate(lab, xy=(beta_x, 1.02), ha='center', fontsize=8, rotation=90)

ax.set_xlabel(r'$\beta_\xi$ = fraction of template mass outside gap')
ax.set_ylabel('Scalar value')
ax.set_title('Four scalar laws as functions of $\\beta$\n(per principal direction)')
ax.legend(loc='center right')
ax.grid(alpha=0.3)
ax.set_xlim(0, 1)
ax.set_ylim(-0.05, 1.1)

plt.suptitle('Four-object decomposition for matched filtering under common mask', fontsize=13)
plt.tight_layout()
plt.savefig(f'{OUTPUT_DIR}/matched_filter_decomposition.png', dpi=100, bbox_inches='tight')
plt.close()
print(f"Saved {OUTPUT_DIR}/matched_filter_decomposition.png")

# ============================================================
# VERIFICATION
# ============================================================

# Check four-object identity: total = suppression + leakage
identity_errors = total_xi - suppression_xi - leakage_xi
print(f"\nFour-object identity: max |error| = {np.max(np.abs(identity_errors)):.2e}")

# Check empirical variance vs predicted (skipping points where MC error is large)
rel_err = np.abs(empirical_var - variances) / np.maximum(variances, 1e-6)
print(f"Empirical vs predicted null variance: mean rel error = {np.mean(rel_err):.4f}, max = {np.max(rel_err):.4f}")

# Check empirical false-alarm rate vs predicted
rel_err_far = np.abs(fa_rate - predicted_fa_rate) / np.maximum(predicted_fa_rate, 1e-3)
print(f"Empirical vs predicted false-alarm rate: mean rel error = {np.mean(rel_err_far):.4f}")

# Save verification record
with open(f'{OUTPUT_DIR}/matched_filter_verification.txt', 'w') as f:
    f.write("=" * 70 + "\n")
    f.write("Matched filtering under common mask: numerical verification\n")
    f.write("Framework: common_mask_correlation.md §6 + statistical_phantoms.md §4.3\n")
    f.write("=" * 70 + "\n\n")
    
    f.write(f"Setup:\n")
    f.write(f"  Domain: 1D periodic [0, 2pi], N={N} grid points\n")
    f.write(f"  Gap: G = [pi/2, 3pi/4], fraction = {gap_fraction:.3f}\n")
    f.write(f"  Templates: Gaussian peaks of sigma=0.15, parameterized by location xi\n")
    f.write(f"  Forward operator: A = I - K (multiplication by mask in position space)\n\n")
    
    f.write(f"Four-object identity (per template location):\n")
    f.write(f"  total = suppression + leakage\n")
    f.write(f"  Max |error|: {np.max(np.abs(identity_errors)):.2e} (machine precision)\n\n")
    
    f.write(f"Detection-statistic null variance prediction:\n")
    f.write(f"  Predicted: t_xi^T A^T A t_xi = ||M_G t_xi||^2 = beta_xi (for unit-norm templates)\n")
    f.write(f"  Empirical (Monte Carlo over T=200 null realizations):\n")
    f.write(f"    Mean relative error: {np.mean(rel_err):.4f}\n")
    f.write(f"    Max relative error:  {np.max(rel_err):.4f}\n\n")
    
    f.write(f"False-alarm rate prediction:\n")
    f.write(f"  At fixed threshold tau = {threshold:.3f}\n")
    f.write(f"  Predicted: P(|N(0, beta_xi)| > tau) varies with xi\n")
    f.write(f"  Empirical (Monte Carlo over T={n_mc_far} null realizations):\n")
    f.write(f"    Mean relative error: {np.mean(rel_err_far):.4f}\n\n")
    
    f.write(f"Conclusion:\n")
    f.write(f"  The framework's prediction t_xi^T A^T A t_xi for the detection-statistic\n")
    f.write(f"  null variance matches Monte Carlo to within finite-sample noise. The\n")
    f.write(f"  non-uniform false-alarm rate as a function of template location is\n")
    f.write(f"  predicted from beta_xi alone (without any data); the empirical rate\n")
    f.write(f"  matches. The four-object structural identity holds to machine precision\n")
    f.write(f"  per template location.\n")

print(f"Saved {OUTPUT_DIR}/matched_filter_verification.txt")

print("\n" + "="*60)
print("All matched-filter figures and verification record generated.")
print("="*60)
