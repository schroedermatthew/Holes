"""
Regression with omitted variables: numerical companion to statistical_phantoms.md §4.1

Concrete demonstration that the framework predicts the bias structure in
omitted-variable regression, exactly. The math is fully linear and the
prediction is verifiable to floating-point precision.

Setup:
- n = 500 samples
- d_o = 4 observed features X_o
- d_u = 3 omitted features X_u
- Controlled cross-correlation between observed and omitted features
- True y = X_o beta_o + X_u beta_u + epsilon
- Fit OLS using only X_o
- Compare empirical hat-beta_o - beta_o to the framework's prediction
  (X_o^T X_o)^{-1} X_o^T X_u beta_u

Framework's predictions (from statistical_phantoms.md §4.1 with §1.3
four-object decomposition):
- Bias formula: E[hat-beta_o] - beta_o = (X_o^T X_o)^{-1} X_o^T X_u beta_u
- This is the analog of phantom_m = -K_{m,n} c in the spectral case
- Coupling kernel K_regression = (X_o^T X_o)^{-1} X_o^T X_u
- The four-object decomposition with P_1 = P_u (unobserved column space)
  and P_2 = P_o (observed column space) gives:
  - Retention beta^2: omitted truth that survives in unobserved direction
  - Suppression (1-beta)^2: omitted truth missing from unobserved coords
  - Leakage beta(1-beta): omitted-variable energy redirected into observed
  - Total 1-beta: full bias-in-fitted-values squared
- Canonical correlations rho_j = cos(theta_j) = sqrt(beta_j) between X_o
  and X_u column spaces govern bias amplification

Output:
- regression_omitted_setup.png: cross-correlation structure
- regression_omitted_bias.png: empirical vs predicted bias
- regression_omitted_phantom.png: phantom interpretation per coefficient
- regression_omitted_decomposition.png: four-object decomposition
- regression_omitted_verification.txt: numerical verification
"""

import os
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle

OUTPUT_DIR = '/mnt/user-data/outputs'
os.makedirs(OUTPUT_DIR, exist_ok=True)

np.random.seed(42)

# ============================================================
# SETUP
# ============================================================

n = 500     # samples
d_o = 4     # observed features
d_u = 3     # omitted features

# Generate features with controlled cross-correlation
# Idea: X_o and X_u share a common low-rank component plus independent noise
# This creates canonical correlations of moderate magnitude

# Common factors (shared between observed and unobserved)
n_shared = 2
F_shared = np.random.randn(n, n_shared)

# Loadings: how each set of features depends on shared factors
# Random loadings, scaled to control canonical correlation magnitude
load_o = np.random.randn(n_shared, d_o) * 0.7  # observed feature loadings
load_u = np.random.randn(n_shared, d_u) * 0.7  # omitted feature loadings

# Independent components for each set
indep_o = np.random.randn(n, d_o) * 1.0
indep_u = np.random.randn(n, d_u) * 1.0

X_o = F_shared @ load_o + indep_o  # n x d_o
X_u = F_shared @ load_u + indep_u  # n x d_u

# Center the features
X_o -= X_o.mean(axis=0)
X_u -= X_u.mean(axis=0)

# True coefficients
beta_o_true = np.array([1.0, -0.5, 0.3, 0.8])
beta_u_true = np.array([1.0, -1.5, 0.7])

# Generate response
noise = 0.5 * np.random.randn(n)
y = X_o @ beta_o_true + X_u @ beta_u_true + noise

# ============================================================
# OLS FITS
# ============================================================

# Full model (oracle): regress on [X_o, X_u]
X_full = np.hstack([X_o, X_u])
beta_full = np.linalg.lstsq(X_full, y, rcond=None)[0]
beta_o_full = beta_full[:d_o]
beta_u_full = beta_full[d_o:]

# Omitted-variable fit: regress on X_o only
beta_o_hat = np.linalg.lstsq(X_o, y, rcond=None)[0]

# Empirical bias from this realization
empirical_bias_one = beta_o_hat - beta_o_true
print(f"True beta_o:    {beta_o_true}")
print(f"Hat beta_o (single sample): {beta_o_hat}")
print(f"Empirical bias (single sample): {empirical_bias_one}")

# Monte Carlo: average bias over many realizations
n_mc = 1000
empirical_bias_samples = np.zeros((n_mc, d_o))
for k in range(n_mc):
    # Same X_o, X_u, but new noise
    noise_k = 0.5 * np.random.randn(n)
    y_k = X_o @ beta_o_true + X_u @ beta_u_true + noise_k
    beta_o_hat_k = np.linalg.lstsq(X_o, y_k, rcond=None)[0]
    empirical_bias_samples[k] = beta_o_hat_k - beta_o_true

empirical_bias_mean = empirical_bias_samples.mean(axis=0)
empirical_bias_std = empirical_bias_samples.std(axis=0)

# Predicted bias from framework
K_regression = np.linalg.solve(X_o.T @ X_o, X_o.T @ X_u)  # d_o x d_u
predicted_bias = K_regression @ beta_u_true

print(f"\nMonte Carlo empirical bias: {empirical_bias_mean}")
print(f"Monte Carlo std:            {empirical_bias_std}")
print(f"Framework predicted bias:   {predicted_bias}")
print(f"Difference (predicted - empirical): {predicted_bias - empirical_bias_mean}")
print(f"|diff| / |std|: {np.abs(predicted_bias - empirical_bias_mean) / empirical_bias_std}")

# ============================================================
# CANONICAL CORRELATION ANALYSIS (Hotelling 1936)
# ============================================================

# Whiten X_o and X_u (compute canonical correlations between subspaces)
# CCA between X_o and X_u via SVD of cross-correlation
# (After centering and standardizing)

# Standard formulation: rho_j are singular values of
# (X_o^T X_o)^{-1/2} X_o^T X_u (X_u^T X_u)^{-1/2}

# Compute Cholesky-style factors
Sigma_oo = X_o.T @ X_o / n
Sigma_uu = X_u.T @ X_u / n
Sigma_ou = X_o.T @ X_u / n

L_oo = np.linalg.cholesky(Sigma_oo)
L_uu = np.linalg.cholesky(Sigma_uu)

# Whitened cross-correlation
M_cross = np.linalg.solve(L_oo, np.linalg.solve(L_uu, Sigma_ou.T).T)
U_cca, S_cca, Vt_cca = np.linalg.svd(M_cross, full_matrices=False)
rho = S_cca  # canonical correlations
beta_cca = rho**2  # squared canonical correlations = principal-angle squared cosines

print(f"\nCanonical correlations between X_o and X_u column spaces:")
print(f"  rho_j: {rho}")
print(f"  beta_j (= rho^2): {beta_cca}")
print(f"  principal angles (deg): {np.degrees(np.arccos(np.clip(rho, -1, 1)))}")

# ============================================================
# FIGURE 1: SETUP - cross-correlation structure
# ============================================================

fig, axes = plt.subplots(1, 3, figsize=(13, 4))

# Cross-correlation matrix between X_o and X_u features
# (after standardization)
X_o_std = X_o / X_o.std(axis=0)
X_u_std = X_u / X_u.std(axis=0)
cross_corr = (X_o_std.T @ X_u_std) / n

ax = axes[0]
im = ax.imshow(cross_corr, cmap='RdBu_r', vmin=-1, vmax=1, aspect='auto')
ax.set_title("Cross-correlation $X_o^TX_u/n$\n(standardized)")
ax.set_xlabel("Omitted feature index")
ax.set_ylabel("Observed feature index")
ax.set_xticks(range(d_u))
ax.set_yticks(range(d_o))
plt.colorbar(im, ax=ax, fraction=0.046)

# Within-X_o correlation
within_o = (X_o_std.T @ X_o_std) / n
ax = axes[1]
im = ax.imshow(within_o, cmap='RdBu_r', vmin=-1, vmax=1, aspect='equal')
ax.set_title("$X_o^TX_o/n$\n(observed-feature correlation)")
ax.set_xticks(range(d_o))
ax.set_yticks(range(d_o))
plt.colorbar(im, ax=ax, fraction=0.046)

# Canonical correlations
ax = axes[2]
ax.bar(range(len(rho)), rho, color='steelblue')
ax.set_xlabel("Canonical pair index $j$")
ax.set_ylabel(r"$\rho_j$")
ax.set_title("Canonical correlations\n(cosines of principal angles)")
ax.set_ylim(0, 1)
ax.set_xticks(range(len(rho)))
ax.grid(axis='y', alpha=0.3)
for j, r in enumerate(rho):
    ax.text(j, r + 0.02, f"{r:.3f}", ha='center', fontsize=9)

plt.suptitle(f"Setup: n={n}, $d_o$={d_o} observed features, $d_u$={d_u} omitted features", 
             fontsize=13)
plt.tight_layout()
plt.savefig(f'{OUTPUT_DIR}/regression_omitted_setup.png', dpi=100, bbox_inches='tight')
plt.close()
print(f"Saved {OUTPUT_DIR}/regression_omitted_setup.png")

# ============================================================
# FIGURE 2: BIAS - empirical vs predicted
# ============================================================

fig, axes = plt.subplots(1, 2, figsize=(13, 5))

# Bar chart: true beta_o, hat beta_o (mean), framework's predicted estimate
beta_o_predicted = beta_o_true + predicted_bias
beta_o_empirical_mean = beta_o_true + empirical_bias_mean

ax = axes[0]
x_pos = np.arange(d_o)
width = 0.25
ax.bar(x_pos - width, beta_o_true, width, label=r'True $\beta_o$', color='gray')
ax.bar(x_pos, beta_o_predicted, width, label=r'Predicted $\beta_o + K_{\rm reg}\beta_u$', 
       color='steelblue')
ax.bar(x_pos + width, beta_o_empirical_mean, width, 
       yerr=empirical_bias_std/np.sqrt(n_mc), capsize=4,
       label=r'Empirical $\hat\beta_o$ (MC mean ± SE)', color='firebrick', alpha=0.7)
ax.set_xlabel("Observed coefficient index")
ax.set_ylabel("Coefficient value")
ax.set_title("True vs framework-predicted vs empirical $\\hat\\beta_o$")
ax.legend()
ax.grid(axis='y', alpha=0.3)
ax.set_xticks(x_pos)
ax.axhline(0, color='black', linewidth=0.5)

# Bias decomposition: contribution per omitted variable
# bias[i] = sum_j K_reg[i,j] * beta_u[j]
ax = axes[1]
# Stacked bar showing contribution from each omitted variable
contribs = K_regression * beta_u_true[None, :]  # d_o x d_u
bottoms_pos = np.zeros(d_o)
bottoms_neg = np.zeros(d_o)
colors = plt.cm.tab10(np.linspace(0, 1, d_u))
for j in range(d_u):
    contrib_j = contribs[:, j]
    pos_part = np.maximum(contrib_j, 0)
    neg_part = np.minimum(contrib_j, 0)
    ax.bar(x_pos, pos_part, width=0.6, bottom=bottoms_pos, 
           label=f'$X_u$ feature {j+1}', color=colors[j])
    ax.bar(x_pos, neg_part, width=0.6, bottom=bottoms_neg, color=colors[j])
    bottoms_pos += pos_part
    bottoms_neg += neg_part

# Overlay empirical bias
ax.errorbar(x_pos, empirical_bias_mean, yerr=empirical_bias_std/np.sqrt(n_mc),
            fmt='ko', markersize=8, label='Empirical bias (MC)', zorder=10)
ax.set_xlabel("Observed coefficient index")
ax.set_ylabel("Bias contribution")
ax.set_title("Bias decomposition: which omitted variables contribute to which observed-coefficient bias")
ax.legend(loc='best', fontsize=8)
ax.grid(axis='y', alpha=0.3)
ax.set_xticks(x_pos)
ax.axhline(0, color='black', linewidth=0.5)

plt.suptitle("Predicted bias matches empirical to within Monte Carlo noise", fontsize=13)
plt.tight_layout()
plt.savefig(f'{OUTPUT_DIR}/regression_omitted_bias.png', dpi=100, bbox_inches='tight')
plt.close()
print(f"Saved {OUTPUT_DIR}/regression_omitted_bias.png")

# ============================================================
# FIGURE 3: PHANTOM INTERPRETATION
# ============================================================

# What an unaware analyst sees: hat-beta_o values, interpreted as the effects of X_o on y
# What the framework reveals: each hat-beta_o[i] = beta_o_true[i] + sum_j K_reg[i,j] beta_u_true[j]
#   The phantom is the "borrowed effect" from omitted variables

fig, axes = plt.subplots(1, 2, figsize=(13, 5))

# Left: what the analyst reports (just hat-beta_o values)
ax = axes[0]
ax.bar(x_pos, beta_o_empirical_mean, color='gray', alpha=0.7)
ax.set_xlabel("Observed coefficient index")
ax.set_ylabel("$\\hat\\beta_o$")
ax.set_title('What an unaware analyst reports\n("$X_o$ feature $i$ has effect $\\hat\\beta_o[i]$ on $y$")')
ax.grid(axis='y', alpha=0.3)
ax.set_xticks(x_pos)
ax.axhline(0, color='black', linewidth=0.5)
for i, v in enumerate(beta_o_empirical_mean):
    ax.text(i, v + 0.05 if v >= 0 else v - 0.1, f"{v:.2f}", ha='center', fontsize=10)

# Right: framework's reading - decompose into "real effect" + "phantom from omitted"
ax = axes[1]
real_effect = beta_o_true
phantom_effect = predicted_bias
# Stack them
ax.bar(x_pos, real_effect, color='forestgreen', label='Real $\\beta_o$ (true effect)', alpha=0.85)
phantom_pos = np.maximum(phantom_effect, 0)
phantom_neg = np.minimum(phantom_effect, 0)
ax.bar(x_pos, phantom_pos, bottom=real_effect, color='firebrick', alpha=0.85, 
       label='Phantom (borrowed from $\\beta_u$ via cross-correlation)')
ax.bar(x_pos, phantom_neg, bottom=real_effect, color='firebrick', alpha=0.85)
ax.set_xlabel("Observed coefficient index")
ax.set_ylabel("Coefficient")
ax.set_title("Framework's reading: $\\hat\\beta_o = \\beta_o + K_{\\rm reg}\\beta_u$\n(real effect + phantom from omitted)")
ax.legend(loc='best')
ax.grid(axis='y', alpha=0.3)
ax.set_xticks(x_pos)
ax.axhline(0, color='black', linewidth=0.5)
# Annotate fractions
for i in range(d_o):
    if abs(beta_o_empirical_mean[i]) > 0.05:
        phantom_frac = phantom_effect[i] / beta_o_empirical_mean[i]
        ax.annotate(f'{phantom_frac*100:+.0f}%\nphantom', 
                    xy=(i, beta_o_empirical_mean[i]),
                    xytext=(i, beta_o_empirical_mean[i] + 0.3),
                    ha='center', fontsize=9,
                    arrowprops=dict(arrowstyle='->', color='black', alpha=0.5))

plt.suptitle("The phantom interpretation: estimated coefficients mix real effects with borrowed effects from omitted variables", 
             fontsize=12)
plt.tight_layout()
plt.savefig(f'{OUTPUT_DIR}/regression_omitted_phantom.png', dpi=100, bbox_inches='tight')
plt.close()
print(f"Saved {OUTPUT_DIR}/regression_omitted_phantom.png")

# ============================================================
# FIGURE 4: FOUR-OBJECT DECOMPOSITION
# ============================================================

# In the regression realization with P_1 = P_u, P_2 = P_o, and "truth" f = X_u beta_u:
# - For each canonical pair direction (rho_j, beta_j = rho_j^2):
#   - retention beta^2: how much of beta_u survives projection onto unobserved
#   - suppression (1-beta)^2: how much of beta_u is missing
#   - leakage beta(1-beta): redirection into observed
#   - total 1-beta: full bias in fitted values per direction

# Decompose beta_u in the canonical-correlation basis V (right singular vectors of M_cross)
# This expresses beta_u in the basis where the principal-angle structure is diagonal

# beta_u in the whitened-canonical basis
# v_j is the j-th canonical direction in the whitened X_u-space
# We need the contribution of beta_u to each canonical direction
# v_j corresponds to L_uu @ Vt_cca[j] in the original X_u coefficient space

# Express beta_u in the canonical basis
# In whitened coords: beta_u_white = L_uu @ beta_u
beta_u_white = L_uu.T @ beta_u_true  # in whitened coords, components along canonical directions
beta_u_canonical = Vt_cca @ beta_u_white  # components along each canonical direction

# Squared magnitude per canonical direction
a_squared = beta_u_canonical**2
total_norm_sq = np.sum(a_squared)

# Four-object decomposition per direction
retention = beta_cca**2
suppression = (1 - beta_cca)**2
leakage = beta_cca * (1 - beta_cca)
total = 1 - beta_cca

# Verify per-direction identity
identity_error = total - suppression - leakage
print(f"\nFour-object identity: max |total - suppression - leakage|: {np.max(np.abs(identity_error)):.2e}")

# Energy in each object (weighted by a_j^2)
retention_energy = a_squared * retention
suppression_energy = a_squared * suppression
leakage_energy = a_squared * leakage
total_energy = a_squared * total

fig, axes = plt.subplots(1, 2, figsize=(13, 5))

# Left: bar chart per canonical direction
ax = axes[0]
n_dir = len(beta_cca)
x_pos = np.arange(n_dir)
width = 0.2
ax.bar(x_pos - 1.5*width, retention, width, label=r'Retention $\beta^2$', color='steelblue')
ax.bar(x_pos - 0.5*width, suppression, width, label=r'Suppression $(1-\beta)^2$', color='firebrick')
ax.bar(x_pos + 0.5*width, leakage, width, label=r'Leakage $\beta(1-\beta)$', color='goldenrod')
ax.bar(x_pos + 1.5*width, total, width, label=r'Total $1-\beta$', color='black', alpha=0.5)
for j in range(n_dir):
    ax.text(j, 1.02, f'$\\rho_{{{j+1}}}={rho[j]:.3f}$\n$\\beta_{{{j+1}}}={beta_cca[j]:.3f}$', 
            ha='center', fontsize=9)
ax.set_xlabel("Canonical direction $j$")
ax.set_ylabel("Squared magnitude (per direction)")
ax.set_title("Four-object decomposition per principal direction\n(scalar laws of $\\beta = \\rho^2$)")
ax.legend(loc='center right')
ax.grid(axis='y', alpha=0.3)
ax.set_xticks(x_pos)
ax.set_ylim(0, 1.15)

# Right: energy distribution (weighted by a_j^2)
ax = axes[1]
labels = ['Retention\n$\\beta^2$', 'Suppression\n$(1-\\beta)^2$', 
          'Leakage\n$\\beta(1-\\beta)$', 'Total\n$1-\\beta$']
totals = [retention_energy.sum(), suppression_energy.sum(), 
          leakage_energy.sum(), total_energy.sum()]

# Per-direction stacked bar showing energy contributions
bottoms = np.zeros(n_dir)
colors_dir = plt.cm.tab10(np.linspace(0, 1, n_dir))
for j in range(n_dir):
    ax.bar(0, retention_energy[j], bottom=bottoms[0] if j == 0 else None, 
           color=colors_dir[j], width=0.6)
    
# Simpler: just bar chart of total energies
ax.clear()
bars = ax.bar(labels, totals, color=['steelblue', 'firebrick', 'goldenrod', 'black'])
for bar, t in zip(bars, totals):
    ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.02,
            f'{t:.3f}', ha='center', fontsize=11)
ax.set_ylabel(r"Energy $\sum_j a_j^2 \cdot$(scalar)")
ax.set_title("Total energy in each object across all canonical directions\n(weighted by $a_j^2$ = $\\beta_u$ component squared)")
ax.grid(axis='y', alpha=0.3)
# Annotate identity check
identity_check = total_energy.sum() - suppression_energy.sum() - leakage_energy.sum()
ax.text(0.95, 0.95, f'Total = Suppression + Leakage check:\nresidual = {identity_check:.2e}',
        transform=ax.transAxes, ha='right', va='top', fontsize=9, family='monospace',
        bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))

plt.suptitle("Four-object decomposition for omitted-variable regression\n(per canonical-correlation direction, then aggregated)", 
             fontsize=12)
plt.tight_layout()
plt.savefig(f'{OUTPUT_DIR}/regression_omitted_decomposition.png', dpi=100, bbox_inches='tight')
plt.close()
print(f"Saved {OUTPUT_DIR}/regression_omitted_decomposition.png")

# ============================================================
# VERIFICATION RECORD
# ============================================================

with open(f'{OUTPUT_DIR}/regression_omitted_verification.txt', 'w') as f:
    f.write("=" * 70 + "\n")
    f.write("Regression with omitted variables: numerical verification\n")
    f.write("Framework: statistical_phantoms.md §4.1 with §1.3 four-object decomposition\n")
    f.write("=" * 70 + "\n\n")
    
    f.write(f"Setup: n={n} samples, d_o={d_o} observed, d_u={d_u} omitted features\n")
    f.write(f"True beta_o: {beta_o_true}\n")
    f.write(f"True beta_u: {beta_u_true}\n\n")
    
    f.write(f"Bias prediction (framework formula):\n")
    f.write(f"  E[hat-beta_o] - beta_o = (X_o^T X_o)^(-1) X_o^T X_u beta_u\n")
    f.write(f"  Predicted: {predicted_bias}\n")
    f.write(f"  Empirical (MC mean over {n_mc} realizations): {empirical_bias_mean}\n")
    f.write(f"  MC standard error: {empirical_bias_std/np.sqrt(n_mc)}\n")
    f.write(f"  |predicted - empirical| / SE: {np.abs(predicted_bias - empirical_bias_mean) / (empirical_bias_std/np.sqrt(n_mc))}\n\n")
    
    f.write(f"Canonical correlations (between X_o and X_u column spaces):\n")
    f.write(f"  rho_j: {rho}\n")
    f.write(f"  beta_j = rho_j^2: {beta_cca}\n")
    f.write(f"  Principal angles (deg): {np.degrees(np.arccos(np.clip(rho, -1, 1)))}\n\n")
    
    f.write(f"Four-object identity check (per canonical direction):\n")
    f.write(f"  total = suppression + leakage\n")
    f.write(f"  Max |residual|: {np.max(np.abs(identity_error)):.2e} (machine precision)\n\n")
    
    f.write(f"Phantom decomposition of hat-beta_o:\n")
    f.write(f"  hat-beta_o[i] = beta_o[i] + (K_regression beta_u)[i]\n")
    for i in range(d_o):
        if abs(beta_o_empirical_mean[i]) > 0.01:
            frac = predicted_bias[i] / beta_o_empirical_mean[i]
            f.write(f"  i={i}: real {beta_o_true[i]:+.3f} + phantom {predicted_bias[i]:+.3f} "
                    f"= total {beta_o_empirical_mean[i]:+.3f} ({frac*100:+.0f}% phantom)\n")
    
    f.write(f"\nConclusion:\n")
    f.write(f"  The framework's bias formula matches the empirical Monte Carlo bias\n")
    f.write(f"  to within sampling error. The four-object decomposition's structural\n")
    f.write(f"  identity total = suppression + leakage holds to machine precision per\n")
    f.write(f"  canonical direction. Each estimated coefficient hat-beta_o[i] decomposes\n")
    f.write(f"  cleanly into the true effect plus a phantom component from omitted\n")
    f.write(f"  variables routed through the cross-correlation X_o^T X_u.\n")

print(f"Saved {OUTPUT_DIR}/regression_omitted_verification.txt")

print("\n" + "="*60)
print("All figures and verification record generated.")
print("="*60)
