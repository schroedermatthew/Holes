# Regression with Omitted Variables

## A concrete numerical companion to *Statistical Phantoms* §4.1

*Working Document · April 2026*

*Companion to: Statistical Phantoms; Phantom Eigenmode Fabrication from Measurement Gaps; Compression–Commutator Geometry (v3); PCA Under a Regional Spatial Mask*

---

## Preface

The regression-with-omitted-variables case is the cleanest realization of the statistical phantom framework: the math is fully linear, the bias formula is exact (not a linearization), and every prediction is verifiable to floating-point precision in expectation. This document parallels the PCA-with-mask companion (`pca_masked_companion.md`) in establishing that the framework's predictions for omitted-variable regression match the empirical bias structure pointwise.

The structural claim from `statistical_phantoms.md` §4.1: the omitted-variable bias

$$\mathbb{E}[\hat\beta_o] - \beta_o = (X_o^T X_o)^{-1} X_o^T X_u \beta_u$$

is the regression analog of the spectral phantom $\hat c_m = -K_{m,n_0} c$, with the **regression coupling kernel**

$$K_{\text{reg}} := (X_o^T X_o)^{-1} X_o^T X_u$$

playing the role of the off-diagonal coupling matrix. Each entry $K_{\text{reg}}[i,j]$ tells you how much an omitted-variable coefficient $\beta_u[j]$ contaminates the observed-variable estimate $\hat\beta_o[i]$. The four-object decomposition (`statistical_phantoms.md` §1.3) applies with $P_1 = P_u$ (unobserved column space) and $P_2 = P_o$ (observed column space), with principal angles between them being the canonical correlations $\rho_j = \cos\theta_j$ (Hotelling 1936).

This document:
1. Constructs a concrete regression with controlled cross-correlation between observed and omitted features.
2. Verifies the bias formula matches Monte Carlo empirical bias to within sampling error.
3. Demonstrates the phantom interpretation: each estimated coefficient decomposes into "real effect" + "phantom borrowed from omitted variables via cross-correlation."
4. Verifies the four-object decomposition's structural identities to floating-point precision.

The companion script `regression_omitted_demonstration.py` produces all figures and the verification record.

---

## Part I — Setup

### 1.1 The data-generating process

Generate $n = 500$ samples with $d_o = 4$ observed features and $d_u = 3$ omitted features. Cross-correlation between observed and omitted is controlled by giving them shared latent factors:

$$X_o = F_{\text{shared}} \Lambda_o + E_o, \qquad X_u = F_{\text{shared}} \Lambda_u + E_u$$

where $F_{\text{shared}} \in \mathbb{R}^{n \times 2}$ is shared factors, $\Lambda_o, \Lambda_u$ are loading matrices, and $E_o, E_u$ are independent noise. This produces moderate canonical correlations between the column spaces of $X_o$ and $X_u$.

True coefficients: $\beta_o = (1.0, -0.5, 0.3, 0.8)$, $\beta_u = (1.0, -1.5, 0.7)$. Response is $y = X_o\beta_o + X_u\beta_u + \varepsilon$ with Gaussian noise of $\sigma = 0.5$.

### 1.2 The cross-correlation structure

The cross-correlation between observed and omitted features is the geometric content of the problem. The figure shows: (left) standardized cross-correlation matrix $X_o^T X_u / n$, (middle) within-observed correlation $X_o^T X_o / n$, (right) the canonical correlations $\rho_j = \cos\theta_j$ between $\mathrm{Range}(X_o)$ and $\mathrm{Range}(X_u)$.

![Setup: cross-correlation structure and canonical correlations](regression_omitted_setup.png)

For this realization:

| Canonical pair $j$ | $\rho_j$ | $\beta_j = \rho_j^2$ | Principal angle |
|---|---|---|---|
| 1 | 0.559 | 0.313 | 56.0° |
| 2 | 0.513 | 0.263 | 59.1° |
| 3 | 0.076 | 0.006 | 85.7° |

Two strong canonical correlations (~0.5) and one weak one (~0.08). The canonical-pair structure is the regression analog of the principal-angle structure between an inference subspace and a measurement subspace in the spectral case.

---

## Part II — The Bias Phenomenon

### 2.1 The empirical question

If you don't know about the omitted variables and you fit OLS on $X_o$ alone, what coefficients do you recover? And how do they relate to the truth?

Compute: $\hat\beta_o = (X_o^T X_o)^{-1} X_o^T y$ on a single realization, and $\hat\beta_o^{\text{MC}}$ averaged over $M = 1000$ Monte Carlo realizations (same $X_o, X_u$, fresh noise each time).

Result on this realization:

| Index $i$ | True $\beta_o[i]$ | Empirical $\hat\beta_o[i]$ (MC mean ± SE) |
|---|---|---|
| 0 | $+1.000$ | $+1.313 \pm 0.001$ |
| 1 | $-0.500$ | $-0.322 \pm 0.001$ |
| 2 | $+0.300$ | $-0.586 \pm 0.001$ |
| 3 | $+0.800$ | $-0.233 \pm 0.001$ |

The estimated coefficients are systematically wrong. Coefficient 2 has a sign flip (true $+0.3$, estimated $-0.59$). Coefficient 3 has its sign flipped and is at zero-crossing. These are not noisy estimates around the truth; they are biased estimates of consistently wrong values.

### 2.2 The framework's prediction

`statistical_phantoms.md` §4.1 gives the bias formula:

$$\text{predicted bias} = K_{\text{reg}} \beta_u = (X_o^T X_o)^{-1} X_o^T X_u \beta_u.$$

Compute this: $K_{\text{reg}} \in \mathbb{R}^{4 \times 3}$ is purely a property of the design matrices (no $y$ involved), and predicted bias is a fixed linear map of $\beta_u$.

For our setup: predicted bias $\approx (+0.312, +0.178, -0.885, -1.034)$.

Compare to empirical bias $\approx (+0.313, +0.178, -0.886, -1.033)$.

Standardized residuals $|$ predicted $-$ empirical $|/$ MC standard error: $(0.07, 0.01, 0.05, 0.05)$.

The framework predicts the bias to within $0.07$ standard errors — well below noise. The bias formula is exact in expectation.

### 2.3 Decomposition by omitted variable

Each entry of the bias decomposes as $\text{bias}[i] = \sum_j K_{\text{reg}}[i,j] \cdot \beta_u[j]$ — a sum of contributions from each omitted variable, weighted by its true coefficient. The figure shows: (left) the bar chart of true $\beta_o$ vs predicted vs empirical (bars match), (right) the same bias decomposed by source omitted variable.

![Bias: empirical vs predicted with decomposition by source](regression_omitted_bias.png)

The predicted bars (steel blue) and empirical Monte Carlo means (firebrick) are visually indistinguishable — the framework's prediction matches Monte Carlo exactly to within sampling error. The decomposition (right) shows which omitted variables contribute to which observed-coefficient bias: most of the bias in coefficient #3 comes from omitted variable #2 (which has $\beta_u[2] = -1.5$, the largest-magnitude omitted coefficient, channeled through the $K_{\text{reg}}[3, 2]$ entry).

---

## Part III — The Phantom Interpretation

The most important thing the framework does, in the regression case as in the PCA case, is name what the recovered estimates actually are.

An analyst running OLS on the observed-only model and seeing $\hat\beta_o = (+1.31, -0.32, -0.59, -0.23)$ interprets these as the effects of $X_o$ on $y$: "Increasing $X_o$ feature 0 by one unit increases $y$ by 1.31, holding the other observed features constant." This is what every statistical-software output supports.

The framework's reading is different. Each estimated coefficient decomposes:

$$\hat\beta_o[i] = \beta_o[i] + \sum_j K_{\text{reg}}[i, j] \cdot \beta_u[j]$$

— the true effect of $X_o[i]$ on $y$, plus a phantom component that is the omitted variables' effects routed through the cross-correlation $X_o^T X_u$.

![Phantom interpretation: what the analyst sees vs what the framework reveals](regression_omitted_phantom.png)

The breakdown for this realization:

| Index $i$ | Empirical $\hat\beta_o$ | Real $\beta_o$ | Phantom $K_{\text{reg}}\beta_u$ | Phantom % |
|---|---|---|---|---|
| 0 | $+1.31$ | $+1.00$ | $+0.31$ | $+24\%$ |
| 1 | $-0.32$ | $-0.50$ | $+0.18$ | $-55\%$ |
| 2 | $-0.59$ | $+0.30$ | $-0.89$ | $+151\%$ (sign-flipped) |
| 3 | $-0.23$ | $+0.80$ | $-1.03$ | $+444\%$ (sign-flipped) |

For coefficient 0, the analyst's reported $1.31$ is 76% real effect, 24% phantom. Tolerable.

For coefficient 1, the analyst sees a coefficient close to zero ($-0.32$); the framework reveals this is a real effect of $-0.50$ partially cancelled by a phantom of $+0.18$ — the omitted variables are *masking* a real effect.

For coefficient 2, the analyst reports a negative coefficient ($-0.59$). The framework reveals the *true effect is positive* ($+0.30$); the entire negative reading is phantom from omitted variables, with magnitude ~3× the true effect.

For coefficient 3, the analyst reports a coefficient near zero ($-0.23$). The framework reveals the true effect is *strongly positive* ($+0.80$); the omitted-variable phantom is $-1.03$, more than fully cancelling and reversing the true effect.

This is the regression realization of the phantom phenomenon. The estimated coefficients aren't approximations of the true coefficients with noise; they are deterministic functions of true coefficients plus structured borrowed effects from omitted variables, with the borrowing direction set by cross-correlations and the borrowing magnitude set by canonical-correlation geometry. **The analyst seeing only the OLS output cannot distinguish real from phantom by inspection.** The framework supplies the decomposition; without it, the regression output is a mixture of signal and contamination with no internal way to separate them.

---

## Part IV — The Four-Object Decomposition

The four-object decomposition (`statistical_phantoms.md` §1.3) specializes to the regression realization with:

- $P_1 = P_u$: projection onto the unobserved column space $\mathrm{Range}(X_u) \subset \mathbb{R}^n$.
- $P_2 = P_o$: projection onto the observed column space $\mathrm{Range}(X_o) \subset \mathbb{R}^n$.
- "Truth" $f = X_u \beta_u$ is the omitted-variable contribution to the response, lying in $\mathrm{Range}(P_1)$.

The principal angles between $\mathrm{Range}(P_o)$ and $\mathrm{Range}(P_u)$ are the canonical-correlation angles $\theta_j$, with $\cos^2\theta_j = \beta_j = \rho_j^2$.

Decomposing $f = X_u \beta_u$ in the canonical basis (the right singular vectors of the whitened cross-correlation), $f = \sum_j a_j u_j$ with squared coefficients $a_j^2$. The four scalar objects per direction:

| Object | Per-direction value | Interpretation in regression realization |
|---|---|---|
| Retention | $\beta^2$ | Omitted-truth surviving along its own canonical direction |
| Suppression | $(1-\beta)^2$ | Omitted-truth missing from its own canonical direction |
| **Leakage** | $\beta(1-\beta)$ | **Omitted-truth redirected into the observed column space — the bias** |
| Total | $1-\beta$ | Squared norm of bias-in-fitted-values per direction |

with the per-direction identity $1 - \beta = (1-\beta)^2 + \beta(1-\beta)$ (total = suppression + leakage), and the energy-weighted aggregate $\sum_j a_j^2 \cdot (\text{scalar})$ giving the total contribution across all canonical directions.

![Four-object decomposition for regression with omitted variables](regression_omitted_decomposition.png)

For our setup, the canonical structure has three directions with $\beta_j \in \{0.313, 0.263, 0.006\}$. The first two have moderate $\beta$ (canonical correlations ~0.5), the third has $\beta \approx 0$ (canonical correlation ~0.08).

Per-direction reading:
- Directions 1 and 2 (moderate $\beta$): Suppression dominates (~50% of per-direction energy each), leakage is moderate (~20% each), total error is large (~70% each). Both directions contribute substantially to the bias.
- Direction 3 (very small $\beta$): Suppression is near 100%, leakage is near zero, total is near 1. This direction is almost orthogonal between observed and unobserved column spaces — the omitted-variable component along this direction has minimal cross-projection into observed coordinates.

Energy-weighted aggregate (across all directions, weighted by $a_j^2$):

| Object | Total energy |
|---|---|
| Retention | 0.903 |
| Suppression | 6.884 |
| Leakage | 2.485 |
| Total | 9.369 |

Identity check: total $-$ suppression $-$ leakage $= -3.55 \times 10^{-15}$ (machine precision). The structural identity holds exactly.

---

## Part V — Verification

### 5.1 Bias formula match

The framework's prediction $K_{\text{reg}} \beta_u$ matches the Monte Carlo empirical bias:

```
Predicted: [+0.312, +0.178, -0.885, -1.034]
Empirical: [+0.313, +0.178, -0.886, -1.033]   (MC over 1000 realizations)
|diff|/SE: [0.07,   0.01,   0.05,   0.05]
```

All four entries match to within 0.07 standard errors. The bias formula is exact in expectation (which it must be — the formula is derived without approximation), and the Monte Carlo confirms this empirically.

### 5.2 Four-object identity

For each canonical direction:

```
total[j] - suppression[j] - leakage[j] = 0 to 7.55e-17 (machine precision)
```

The structural identity holds exactly for each principal direction.

### 5.3 Aggregate energy identity

```
Total energy - Suppression energy - Leakage energy = -3.55e-15 (machine precision)
```

After weighting by $a_j^2$ across all directions, the aggregate identity also holds to machine precision.

### 5.4 Bias decomposition consistency

For each estimated coefficient $\hat\beta_o[i]$, the decomposition $\hat\beta_o[i] = \beta_o[i] + (K_{\text{reg}} \beta_u)[i]$ holds in expectation. Empirically, the difference between the Monte Carlo mean $\hat\beta_o$ and the predicted decomposition $\beta_o + K_{\text{reg}}\beta_u$ is below $0.001$ in all four entries, with sampling error $\sim 0.001$ — exact agreement at the level of MC noise.

---

## Part VI — What This Demonstrates

The omitted-variable regression case is the cleanest demonstration of the statistical phantom framework's predictive content:

1. **The bias is exactly predicted, not approximately.** The formula $K_{\text{reg}} \beta_u$ is an algebraic identity, not a linearization. Empirical Monte Carlo averages converge to it as the sample count grows.

2. **The bias has structure.** It is not a random error around the truth; it is a deterministic function of true coefficients $\beta_u$ routed through the cross-correlation kernel $K_{\text{reg}}$. Different cross-correlation structures produce different bias patterns; the framework computes all of them in advance.

3. **The phantom can dominate the signal.** In our setup, two of four estimated coefficients have phantom magnitudes exceeding the true effect, including one with sign-flipping. The framework reveals this; OLS output alone hides it.

4. **The four-object decomposition's structural identities are exact.** Total = suppression + leakage holds per principal direction to machine precision; the aggregate version holds across all directions.

5. **The connection to canonical correlation analysis (Hotelling 1936) is direct.** The principal angles between observed and unobserved column spaces are the canonical correlations; the framework's mask-adapted basis is the canonical-pair basis; the bias structure is read directly from the canonical-correlation geometry.

The same level of predictive specificity that the original spectral phantom suite achieves for the multiplication-defect case ($\hat c_m = -K_{m,n_0} c$ with $K$ from the gap geometry) is achieved here for the regression case ($\hat\beta_o = \beta_o + K_{\text{reg}}\beta_u$ with $K_{\text{reg}}$ from the design-matrix cross-correlation). The math is fully linear, the prediction is verifiable to floating-point precision, and the phantom interpretation has direct operational consequences for how regression output should be read.

The phantom phenomenon in regression with omitted variables is well-known to econometricians as omitted-variable bias. The framework's contribution is *not* discovering this — it is recognizing that omitted-variable bias is the regression realization of the same operator-theoretic structure that produces phantom eigenmodes in spectral analysis with measurement gaps. The geometric structure is shared; the realization-specific kernels ($K$ for spectral, $K_{\text{reg}}$ for regression) differ; the four-object decomposition gives the unified scalar accounting.

---

## Development Record

This document is the second concrete numerical companion to `statistical_phantoms.md` Part IV (after `pca_masked_companion.md` for §4.2). It establishes the regression-with-omitted-variables case at the same level of empirical verification: bias formula matches Monte Carlo to within sampling error, four-object identities hold to machine precision, the phantom interpretation makes the borrowed-effect structure explicit.

What this document does:

- Constructs a concrete regression with controlled cross-correlation between observed and omitted features.
- Verifies the bias formula $(X_o^T X_o)^{-1} X_o^T X_u \beta_u$ matches Monte Carlo to within $0.07$ standard errors across all four observed coefficients.
- Demonstrates the phantom interpretation with explicit decomposition of each estimated coefficient into real effect + omitted-variable phantom.
- Verifies the four-object decomposition's structural identities to machine precision per canonical direction and aggregated.

What this document does not do:

- Address the case where $X_o$ and $X_u$ are not given but must be inferred (the realistic econometric setting). The framework predicts what the bias *would* be given the cross-correlation structure; identifying that structure when both observed and unobserved features are unknown is a different problem.
- Develop the second-moment phantom (heteroskedasticity-robust standard errors and their misspecification under omitted-variable correlation). Sketched in `statistical_phantoms.md` §4.1 but not numerically demonstrated here.
- Develop the eigenstructure-phantom case for principal-component regression (`statistical_phantoms.md` §4.1, end of section). The PC regression case has its own bias structure that lifts the omitted-variable analysis to a principal-direction-rotation phantom. Open work.
- Compare instrumental-variable methods quantitatively. Mentioned in §4.1 as the econometric design-rule answer; numerical comparison would extend the demonstration.

Likely revisions:

- The cross-correlation structure used here is constructed via shared latent factors. A more realistic econometric setup (omitted confounder, selection bias, measurement error) would produce different $K_{\text{reg}}$ structures with their own characteristic phantom signatures.
- The connection to causal-inference vocabulary (treatment effects, confounding bias) is implicit. Drawing the explicit map from the framework's vocabulary to causal-inference conventions would broaden the document's audience.

The role of this companion. Together with `pca_masked_companion.md`, this document establishes that the statistical phantom framework's claims have specific, verifiable, predictive content in two of the realizations from `statistical_phantoms.md` Part IV. The framework predicts not just the existence of phantoms but their pointwise structure, magnitude per principal direction, and decomposition into real-versus-borrowed components. The original spectral phantom suite delivers this level of demonstration for the multiplication-defect case; the statistical extension can deliver it for each of its realizations when the demonstrations are built out concretely.
