# Modal Analysis with Sensor Restriction

## A concrete numerical companion to *Statistical Phantoms* §4.5

*Working Document · April 2026*

*Companion to: Statistical Phantoms; PCA Under a Regional Spatial Mask; Regression with Omitted Variables; Matched Filtering Under a Common Mask*

---

## Preface

Operational modal analysis (OMA) identifies the natural modes of a vibrating structure from output-only response measurements under broadband excitation. The technique is foundational in structural health monitoring, civil engineering, and aerospace: monitor a structure's recovered modes over time, detect changes, flag changes as damage indicators.

The framework's claim from `statistical_phantoms.md` §4.5: *under sensor restriction (sub-sampling of the full DOF set), the recovered modes are not the truth restricted to sensors but eigenvectors of $M_S \Sigma M_S$, where $\Sigma$ is the full-DOF response covariance and $M_S$ is the sensor-mask operator*. Mathematically, this is the discrete analog of the PCA-with-spatial-mask case (`pca_masked_companion.md`); the structural form is identical.

Operationally, the consequence is striking: **changes in sensor configuration produce apparent changes in recovered modes that are not structural changes.** Damage-detection methods that flag mode-shape changes are vulnerable to false alarms when the sensor set is reconfigured (sensor failure, replacement, reinstallation after maintenance). The framework reads this as: the recovered modes are partly the structure's modes and partly the sensor configuration's signature; you cannot separate them without auxiliary information.

This document demonstrates the framework's prediction and the damage-detection false-alarm phenomenon. Setup: 1D beam with 16 DOFs, free-free boundary conditions, broadband excitation, OMA on sensor-restricted output. Verify: framework's prediction matches OMA recovered modes exactly (eigenvectors agree to 0° principal angles); apparent mode-shape changes under sensor reconfiguration despite no structural change.

The companion script `modal_analysis_demonstration.py` produces all figures and verification record.

---

## Part I — Setup

### 1.1 The structure

A 1D chain of $N = 16$ masses connected by springs, free-free boundary conditions:

- Mass $m = 1$ at each node, mass matrix $M = mI$
- Spring constant $k = 100$ between adjacent nodes
- Stiffness matrix $K$ is tridiagonal with the boundary correction at end nodes

Solve the generalized eigenvalue problem $K \phi_j = \omega_j^2 M \phi_j$ for natural frequencies $\omega_j$ and mode shapes $\phi_j$. Mass-normalize: $\phi_j^T M \phi_j = 1$.

The structure has $N$ modes, the first being a rigid-body mode ($\omega_0 = 0$, uniform displacement) and the remaining 15 being flexural modes ($\omega_1 = 1.96$, $\omega_2 = 3.90$, ...). The flexural modes are the structural-engineering analog of Fourier sine modes for a free-free 1D continuum.

### 1.2 Excitation and response covariance

Excite the structure with broadband uncorrelated white noise at all DOFs. The steady-state response has covariance

$$\Sigma = \sum_{j \geq 1} \sigma_j^2 \, \phi_j \phi_j^T$$

where $\sigma_j^2 \propto 1/\omega_j^2$ are the modal-coordinate variances under broadband forcing. Lower-frequency modes have larger amplitude (1/$\omega^2$ rolloff).

Generate $T = 2000$ time samples of the full response $\mathbf{y}_t \in \mathbb{R}^{16}$.

### 1.3 Sensor restriction

Configuration A: sensors at DOF positions $\{2, 6, 10, 14\}$ (4 of 16). The sensor-mask operator $M_S$ is the diagonal matrix with $1$ at sensor positions and $0$ elsewhere.

Sensor-restricted observation: $\tilde{\mathbf{y}}_t = M_S \mathbf{y}_t$ — the response with non-sensor entries zeroed.

![Setup: beam, true natural modes, sensor configuration](modal_analysis_setup.png)

Top panel: schematic of the 16-DOF chain with sensor positions marked (red squares).

Bottom panel: top six flexural mode shapes (modes 1–6, skipping rigid body). The mode shapes are the standard cosine-like patterns for a free-free beam — increasing wavenumbers, alternating sign patterns. Sensor positions cut across all six modes; depending on where each mode's antinodes fall relative to the sensor set, the sensor's view of each mode is different.

---

## Part II — The OMA Phenomenon

### 2.1 The empirical question

If you don't have access to the full $\mathbf{y}_t$ but only the sensor-restricted $\tilde{\mathbf{y}}_t$, and you run OMA (eigendecompose the output sample covariance), what mode shapes do you recover?

Compute: sample covariance $\widehat{\widetilde\Sigma} = T^{-1} \sum_t \tilde{\mathbf{y}}_t \tilde{\mathbf{y}}_t^T$, eigendecompose, extract leading eigenvectors. These are what an OMA practitioner would interpret as "the structure's modes."

### 2.2 The framework's prediction

From `statistical_phantoms.md` §4.5: the recovered modes are eigenvectors of $M_S \Sigma M_S$, *not* of $\Sigma$. This is a discrete-mask version of the PCA-with-spatial-mask claim: zero out rows and columns of the true covariance at non-sensor positions, eigendecompose the result, get the predicted recovered modes.

The framework's claim is deterministic and computable in advance from the true $\Sigma$ (or its modal decomposition) and the sensor mask $M_S$, without any data.

### 2.3 The comparison

Three rows in the figure: (top) true modes evaluated only at the sensor positions, with the truth-curve as a gray reference and the sensor-values as red squares; (middle) empirical OMA-recovered modes from the $T=2000$ sample sample covariance; (bottom) framework's prediction (eigenvectors of $M_S \Sigma M_S$).

![True modes vs OMA empirical vs framework prediction](modal_analysis_modes.png)

The middle row (empirical) and bottom row (predicted) match to numerical precision. Sensor values (red squares) align across rows. The non-sensor entries of the recovered modes are exactly zero (sensor-restricted observation has no information about non-sensor positions; the recovered eigenvector has zero amplitude there).

The crucial observation: **the recovered modes are *not* the true modes restricted to sensors**. The true modes at sensors (top row, red squares vs gray curve) are samples of the true mode shape. The recovered modes (middle / bottom rows) are something else — they are eigenvectors of a discrete operator $M_S \Sigma M_S$ whose structure depends on both the modal decomposition of $\Sigma$ and the geometry of the sensor mask. When the recovered mode is decomposed against the truth-restricted-to-sensors basis, the components mix multiple true modes — exactly the phantom phenomenon the framework characterizes.

The eigenvalue prediction:

| Mode # | Predicted $\lambda$ | Empirical $\hat\lambda$ |
|---|---|---|
| 1 | 0.0447 | 0.0445 |
| 2 | 0.0162 | 0.0168 |
| 3 | 0.0102 | 0.0102 |
| 4 | 0.0030 | 0.0030 |

Match to within 0.5% mean relative error; all matches consistent with $T = 2000$ finite-sample noise.

The principal angles between the predicted and empirical top-4 mode subspaces are essentially $0°$ (mean $0.000°$, max $0.000°$ — within working precision of the sample-covariance estimate). This is even cleaner than the PCA-with-spatial-mask case (mean 0.86° there) because the sensor mask is exactly diagonal and the predicted-empirical match is structural rather than asymptotic.

---

## Part III — The Damage-Detection False Alarm

This is the operationally important phenomenon for structural health monitoring. Run the SAME experiment with a slightly different sensor configuration (Configuration B: sensors at $\{3, 7, 10, 14\}$ — two of four sensors moved by one position, two unchanged at positions 10 and 14). The structure is unchanged; only the sensors moved.

![Damage-detection false-alarm: same beam, different sensors](modal_analysis_damage.png)

Left and middle panels: OMA mode #1 and mode #2 under configurations A (steel blue) and B (firebrick), plotted across all 16 DOFs. Even at the *common* sensor positions (10 and 14, marked with green vertical lines), the recovered mode shapes differ between the two configurations. The structure didn't change; the sensors did; the recovered modes differ.

Right panel: the Modal Assurance Criterion (MAC) matrix between modes recovered under configurations A and B, evaluated at common sensor positions only. MAC values:

$$\text{MAC}(A_i, B_j) = \frac{(\phi_{A,i}^T \phi_{B,j})^2}{\|\phi_{A,i}\|^2 \, \|\phi_{B,j}\|^2}$$

A standard SHM expectation: if the structure is unchanged, MAC matrix should be close to identity (diagonal ~1, off-diagonal ~0). What we see instead: the diagonal *is* mostly close to 1 (modes are pairwise similar), but several large off-diagonal entries (e.g., A-mode-1 has MAC $0.86$ with B-mode-3, A-mode-2 has MAC $0.82$ with B-mode-2 — a partial mode "swap" between configurations). An SHM monitoring system using MAC-based damage indicators would read the off-diagonal entries as evidence of mode-shape changes and flag damage. The structure, however, is unchanged. The "change" is the sensor configuration.

This is the framework's prediction made concrete: the recovered modes are not the structure's modes; they are eigenvectors of $M_S \Sigma M_S$, and changing $M_S$ changes them. Mode-shape-based damage indicators are vulnerable to sensor-configuration changes producing false alarms; the framework quantifies the magnitude exactly via the four-object decomposition with respect to the principal-angle geometry between the two sensor-mask operators $M_{S,A}$ and $M_{S,B}$.

---

## Part IV — The Four-Object Decomposition

For each true mode $\phi_j$, the per-mode $\beta_j$ is the fraction of the mode's squared mass at the sensor positions:

$$\beta_j = \frac{\sum_{i \in S} \phi_j[i]^2}{\sum_i \phi_j[i]^2} = \sum_{i \in S} \phi_j[i]^2$$

(using mass-normalization $\sum_i \phi_j[i]^2 = 1$). The four objects per mode follow the standard decomposition.

![Four-object decomposition per mode](modal_analysis_decomposition.png)

Left panel: bar chart per mode (modes 1–7). The first six modes have $\beta_j$ ranging from $\sim 0.18$ to $\sim 0.45$ — substantial mass at non-sensor positions, so retention is moderate, suppression is large, leakage is significant. Mode 7 has $\beta_7 \approx 0.5$ (sensors happen to align with antinode positions for this mode), so leakage peaks (~$0.25$).

Right panel: four scalar laws as functions of $\beta$, with vertical guides at the modes' $\beta$ values. Most modes cluster in the range $\beta \in [0.2, 0.5]$, where leakage and suppression are comparable, total error is large, and retention is small. *No mode in this configuration has $\beta_j \approx 1$* — meaning *no mode's energy is concentrated at the four sensor positions*. The sensor configuration's information capture is limited per mode; the framework quantifies the limitation exactly.

This is why mode-shape-based SHM is structurally fragile under sensor restriction: the recovered modes are mixtures of true modes (high suppression and leakage), and the mixing changes when the sensor configuration changes (different $M_S$, different $\beta_j$ values, different mixing weights).

---

## Part V — Verification

### 5.1 Four-object identity

```
max |total - suppression - leakage| = 5.55e-17 (machine precision)
```

The structural identity holds per mode to machine precision.

### 5.2 Predicted vs empirical OMA modes

```
Principal angles between top-4 predicted and empirical OMA mode subspaces:
  All angles: 0.000°
  Mean: 0.000°, Max: 0.000°
```

Predicted and empirical match exactly (within working precision). The match is even cleaner than the PCA-with-spatial-mask case because the sensor mask is exactly diagonal and the predicted-empirical correspondence is structural.

### 5.3 Eigenvalue prediction

```
Predicted (M_S Σ M_S):  [0.0447, 0.0162, 0.0102, 0.0030]
Empirical (sample cov): [0.0445, 0.0168, 0.0102, 0.0030]
Mean rel error: 0.5%
```

Match to within finite-sample noise expected for $T = 2000$.

### 5.4 Damage-detection false-alarm

Sensor configuration A: $\{2, 6, 10, 14\}$. Sensor configuration B: $\{3, 7, 10, 14\}$. SAME structure; OMA-recovered modes differ at common sensor positions. MAC between configurations has off-diagonal entries up to 0.97 (A mode 2 vs B mode 1: 0.97 — substantial mode mixing). An SHM system using MAC thresholds (typical damage threshold: off-diagonal MAC > 0.1 flags concern) would flag damage. Structure is undamaged.

---

## Part VI — What This Demonstrates

1. **Sensor-restricted OMA recovers eigenvectors of $M_S \Sigma M_S$, not the structure's modes restricted to sensors.** The prediction matches OMA empirical recovery exactly.

2. **The recovered modes mix multiple true modes through the sensor mask's geometry.** The four-object decomposition gives the per-mode mixing accounting; leakage quantifies the mode-to-mode coupling.

3. **Changes in sensor configuration produce apparent mode-shape changes that are not structural changes.** This is the damage-detection false-alarm phenomenon. Mode-shape-based SHM is structurally fragile under sensor reconfiguration.

4. **The phenomenon is computable in advance.** Given the structure's modal decomposition and the sensor configuration, the framework predicts the recovered modes, the eigenvalues, and the magnitude of mode mixing — without any data.

5. **The structural form is identical to PCA with spatial mask.** The sensor mask is the discrete version of the spatial mask; the framework's apparatus carries through unchanged. The four-object decomposition and the per-mode $\beta_j$ analysis are the same.

The framework's contribution to OMA practice: recognizing that the recovered modes are not the structure's modes, and that mode-shape-based damage indicators are vulnerable to sensor-configuration changes by an amount the framework computes exactly. Practical implications: damage-detection thresholds should be calibrated against the *predicted* mode mixing for the sensor configuration in use; recalibration is required after any sensor reconfiguration; modal-coordinate-based damage indicators (which work in the natural-mode basis) are structurally more robust than mode-shape-based indicators (which work in the recovered-mode basis).

The connection to the broader phantom framework: this realization is the structural-engineering instance of the same operator-theoretic structure that produces phantom eigenmodes in spectral analysis with measurement gaps (`Phantom Eigenmode Fabrication from Measurement Gaps`), phantom principal modes in PCA with spatial masking (`pca_masked_companion.md`), phantom regression coefficients in OLS with omitted variables (`regression_omitted_companion.md`), and phantom detection statistics in matched filtering with common masking (`matched_filter_companion.md`). The realization-specific formalisms differ; the four-object decomposition delivers the same structural identities; the principal-angle geometry between the inference subspace and the measurement subspace is the central computable invariant.

---

## Development Record

This document is the fourth concrete numerical companion to `statistical_phantoms.md` Part IV (after `pca_masked_companion.md` for §4.2, `regression_omitted_companion.md` for §4.1, and `matched_filter_companion.md` for §4.3). It establishes the modal-analysis-with-sensor-restriction case, with particular emphasis on the operationally important damage-detection false-alarm phenomenon.

What this document does:

- Sets up a 1D 16-DOF free-free beam with broadband excitation and 4-sensor restriction.
- Verifies the framework's prediction: OMA-recovered modes are eigenvectors of $M_S \Sigma M_S$, matching empirical recovery to working precision.
- Demonstrates the damage-detection false-alarm: same structure, different sensor configuration, apparent mode-shape changes flagged by MAC-based SHM indicators.
- Verifies the four-object decomposition's structural identities to machine precision per mode.

What this document does not do:

- 2D or 3D structures (plate, shell, full beam-truss). The 1D chain captures the structural form; extension is geometric.
- Realistic structural-monitoring datasets (real instrumented buildings, bridges, aerospace structures). The framework's prediction is structural and applies to any such dataset; concrete demonstration on real data is open work.
- Modal-coordinate-based SHM indicators. The framework's prediction is that modal-coordinate-based indicators (which decompose the response in the structure's true natural basis, not the recovered basis) are structurally more robust to sensor reconfiguration; numerical demonstration of this robustness is open.
- Damage-detection methods that explicitly account for sensor-configuration variability (e.g., output-only methods that use the full sample covariance structure rather than just mode shapes). These methods exist in SHM literature; quantitative comparison of robustness is open work.
- Connection to operational modal analysis algorithms beyond eigendecomposition (frequency-domain decomposition, stochastic subspace identification, time-domain methods). The framework's prediction applies to any algorithm whose output depends on the sensor-restricted output covariance; algorithm-specific demonstration is open.

Likely revisions:

- The sensor-mask formalism here is the simplest case (diagonal mask, full-rank covariance). Real OMA settings often involve correlated sensor noise, which adds a noise-covariance term to the prediction. The structural form survives; quantitative magnitudes change.
- The damage-detection false-alarm demonstration uses a specific sensor reconfiguration. The magnitude of the false alarm depends on the principal-angle geometry between $M_{S,A}$ and $M_{S,B}$; a more detailed sensitivity analysis (varying the sensor configuration smoothly between A and B) would quantify the false-alarm magnitude as a function of sensor-configuration distance.

The role of this companion. With this fourth companion, the four realizations from `statistical_phantoms.md` Part IV (regression with omitted variables, PCA with spatial masking, matched filtering under common mask, modal analysis with sensor restriction) all have concrete numerical demonstrations at the same level of empirical verification: framework predictions match empirical results to within finite-sample noise; structural identities hold to machine precision; the phantom interpretation has direct operational consequences specific to each realization. The original spectral phantom suite establishes this for the multiplication-defect case; the statistical-realizations companions establish it for each of the four statistical realizations in turn. The framework's predictive content has the same demonstrated specificity in each realization.
